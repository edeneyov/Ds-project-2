import java.util.Random;
/*
 * username1: reshitd 212075667
 * UserName2: edeneyov 211698881
 */
public class LPHashTable extends OAHashTable {
	ModHash hash;
	public LPHashTable(int m, long p) {
		super(m);
		hash = new ModHash(m, p);
	}
	
	@Override
	public int Hash(long x, int i) {
		return (hash.Hash(x)+i)% this.m ;
	}
	
}
